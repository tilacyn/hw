package com.nduginets.ml;

import Jama.Matrix;
import com.nduginets.ml.algorithm.LinearRegressionGradient;

import java.io.*;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import com.nduginets.ml.algorithm.LinearRegressionMatrix;
import org.javatuples.Pair;
import org.javatuples.Quartet;
import org.knowm.xchart.SwingWrapper;
import org.knowm.xchart.XYChart;
import org.knowm.xchart.XYChartBuilder;
import org.knowm.xchart.XYSeries;
import org.knowm.xchart.style.Styler;

public class MainRegression {

    public static void main(String[] args) {
        //gradientDecision();
        gradientMatrix();
        drawPlot();
    }

    private static Quartet<Double[][], Double[], Double[][], Double[]> readInput(File file) {
        Double xTest[][];
        Double yTest[];
        Double xValidate[][];
        Double yValidate[];
        try (Scanner scanner = new Scanner(file)) {

            int m = scanner.nextInt();
            int n = scanner.nextInt();
            xTest = new Double[n][m + 1];
            yTest = new Double[n];
            buildMatrixes(n, m, scanner, xTest, yTest);

            n = scanner.nextInt();
            xValidate = new Double[n][m + 1];
            yValidate = new Double[n];
            buildMatrixes(n, m, scanner, xValidate, yValidate);
        } catch (FileNotFoundException e) {
            throw new UncheckedIOException(e);
        }
        return new Quartet<>(xTest, yTest, xValidate, yValidate);
    }

    private static void buildMatrixes(int n, int m, Scanner scanner, Double x[][], Double y[]) {
        for (int i = 0; i < n; i++) {
            for (int j = 1; j <= m; j++) {
                int v = scanner.nextInt();
                x[i][j] = v + 0.0d;
            }
            int v = scanner.nextInt();
            x[i][0] = 1 + 0.0d;
            y[i] = v + 0.0d;
        }
    }

    private static double[][] toArray(Double[][] a) {
        double[][] result = new double[a.length][a[0].length];
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[0].length; j++) {
                result[i][j] = a[i][j];
            }
        }
        return result;
    }


    private static double[] toArray(Double[] a) {
        double[] result = new double[a.length];
        for (int i = 0; i < a.length; i++) {
            result[i] = a[i];
        }
        return result;
    }

    // ============================================================
    private static void gradientDecision() {
        File root = new File(MainRegression.class.getClassLoader().getResource("").getFile()).getParentFile();
        File gradient = Paths.get(root.toString(), "resources", "gradient.txt").toFile();
        try (Writer w = new FileWriter(gradient)) {
            w.write("7\n");
            for (int path = 1; path < 8; path++) {
                String filePath = String.format("regression/%d.txt", path);
                String fileName = MainRegression.class.getClassLoader().getResource(filePath).getFile();
                System.err.println(fileName);
                List<Integer> steps = Arrays.asList(100, 200, 400, 500, 1_000, 2_000, 5_000, 10_000);
                w.write(String.format("%d %d\n", path, steps.size()));
                solveRegressionGradient(new File(fileName), steps, w);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static void solveRegressionGradient(File regressionFile, List<Integer> iterateSteps, Writer w) throws IOException {
        Quartet<Double[][], Double[], Double[][], Double[]> values = readInput(regressionFile);
        double xTest[][] = toArray(values.getValue0());
        double yTest[] = toArray(values.getValue1());
        double xValidate[][] = toArray(values.getValue2());
        double yValidate[] = toArray(values.getValue3());
        LinearRegressionGradient gradient = new LinearRegressionGradient(xTest, yTest);
        for (int i : iterateSteps) {
            gradient.solve(i);
            double result = gradient.errorValidate(xValidate, yValidate);
            System.err.printf("%d %.10f\n", i, result);
            w.write(String.format("%d %.10f\n", i, result));
        }
    }

    private static void gradientMatrix() {
        File root = new File(MainRegression.class.getClassLoader().getResource("").getFile()).getParentFile();
        File gradient = Paths.get(root.toString(), "resources", "matrix.txt").toFile();
        try (Writer w = new FileWriter(gradient)) {
            for (int path = 1; path < 8; path++) {
                String filePath = String.format("regression/%d.txt", path);
                String fileName = MainRegression.class.getClassLoader().getResource(filePath).getFile();
                System.err.println(fileName);
                w.write(String.format("file# %d\n", path));
                solveRegressionMatrix(new File(fileName), w);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void solveRegressionMatrix(File regressionFile, Writer w) throws IOException {
        Quartet<Double[][], Double[], Double[][], Double[]> values = readInput(regressionFile);
        double xTest[][] = toArray(values.getValue0());
        double yTest[] = toArray(values.getValue1());
        double xValidate[][] = toArray(values.getValue2());
        double yValidate[] = toArray(values.getValue3());
        LinearRegressionMatrix gradient = new LinearRegressionMatrix(xTest.length, xTest, yTest);
        double lambda = gradient.findLambda();
        System.err.println("best lambda = " + lambda);
        w.write(String.format("lambda=%.5f\n", lambda));
        Matrix weights = gradient.findWeightForLambda(lambda);
        String array = Arrays.deepToString(weights.getArray());
        System.err.println(array);
        w.write(array + "\n");
        double error = gradient.costError(weights, xValidate, yValidate);
        System.err.println("error = " + error);
        w.write(String.format("error=%.10f\n", error));
    }

    private static void drawPlot() {
        String gradient = MainRegression.class.getClassLoader().getResource("gradient.txt").getFile();
        List<List<Pair<Integer, Double>>> data = new ArrayList<>();
        try (Scanner scanner = new Scanner(new File(gradient))) {
            int cnt = scanner.nextInt();
            for (int c = 0; c < cnt; c++) {
                int fileName = scanner.nextInt();
                int number = scanner.nextInt();
                List<Pair<Integer, Double>> vector = new ArrayList<>();
                for (int i = 0; i < number; i++) {
                    int id = scanner.nextInt();
                    double v = scanner.nextDouble();
                    vector.add(new Pair<>(id, v));
                }
                data.add(vector);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        XYChart chart =
                new XYChartBuilder()
                        .width(800)
                        .height(600)
                        .title("error")
                        .xAxisTitle("step")
                        .yAxisTitle("")
                        .build();

        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNW);
        chart.getStyler().setDefaultSeriesRenderStyle(XYSeries.XYSeriesRenderStyle.Line);
        chart.getStyler().setYAxisLabelAlignment(Styler.TextAlignment.Right);
        chart.getStyler().setYAxisDecimalPattern("#.####");
        chart.getStyler().setPlotMargin(0);
        chart.getStyler().setPlotContentSize(.95);

        for (int i = 0; i < data.size(); i++) {
            List<Integer> a = new ArrayList<>();
            List<Double> b = new ArrayList<>();
            for (Pair<Integer, Double> p : data.get(i)) {
                a.add(p.getValue0());
                b.add(p.getValue1());
            }
            chart.addSeries("file=" + (i + 1), a, b);
        }
        new SwingWrapper<XYChart>(chart).displayChart();

    }
}
