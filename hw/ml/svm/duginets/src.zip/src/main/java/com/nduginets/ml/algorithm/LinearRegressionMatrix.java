package com.nduginets.ml.algorithm;

import Jama.Matrix;

public final class LinearRegressionMatrix {

    private final double x[][];
    private final double y[][];
    private final int rows;

    public LinearRegressionMatrix(int rows, double[][] x, double[] y) {
        this.y = new Matrix(new double[][]{y}).transpose().getArray();
        this.x = x;
        this.rows = rows;
    }

    /**
     * find best vector use cross validation by lambda
     *
     * @return best weight vector
     */
    public double findLambda() {

        double bestLambda = 1;
        double bestMeasure = Double.MAX_VALUE;
        for (double lambda = 0.1; lambda <= 1; lambda += 0.1) {

            double error = 0;
            try {
                int iterate = Math.min(5, rows);
                for (int i = 0; i < iterate; i++) {
                    double x1[][] = subArrayWithout(x, i);
                    double y1[][] = subArrayWithout(y, i);
                    Matrix xm = new Matrix(x1);
                    Matrix ym = new Matrix(y1);
                    Matrix test = new Matrix(new double[][]{x[i]}).transpose();

                    Matrix weightVector = findWeight(xm, ym, lambda);
                    Matrix resultMatrix = weightVector.arrayTimes(test);
                    double result = 0;
                    for (int j = 0; j < x[i].length; j++) {
                        result += resultMatrix.get(j, 0);
                    }
                    error += Math.pow(y[i][0] - result, 2);
                }
            } catch (Exception e) {
                System.err.println(e.toString());
                System.err.println("lambda=" + lambda);
                continue;
            }
            System.err.println("lambda = " + lambda);
            if (error < bestMeasure) {
                bestLambda = lambda;
                bestMeasure = error;
            }
        }
        return bestLambda;
    }

    private Matrix findWeight(Matrix xm, Matrix ym, double lambda) {
        //(A^T * A + t * I) ^ (-1) *A^T * y
        Matrix identity = Matrix.identity(xm.getColumnDimension(), xm.getColumnDimension()).times(lambda);
        Matrix bracketExpression = (xm.transpose().times(xm).plus(identity)).inverse();
        return bracketExpression.times(xm.transpose()).times(ym);
    }

    public Matrix findWeightForLambda(double lambda) {
        return findWeight(new Matrix(x), new Matrix(y), lambda);
    }

    private double[][] subArrayWithout(double[][] a, int withoutIdx) {
        double r[][] = new double[a.length - 1][a[0].length];
        int idx = 0;
        for (int i = 0; i < a.length; i++) {
            if (i == withoutIdx) {
                continue;
            }
            System.arraycopy(a[i], 0, r[idx], 0, a[0].length);
            idx++;
        }
        return r;
    }


    public double costError(Matrix weight, double[][] x, double[] y) {
        double yMax = Integer.MIN_VALUE;
        double yMin = Integer.MAX_VALUE;

        double rmsd = 0;

        for (int i = 0; i < x.length; i++) {
            Matrix test = new Matrix(new double[][]{x[i]}).transpose();
            Matrix resultMatrix = weight.arrayTimes(test);
            double result = 0;
            for (int j = 0; j < x[i].length; j++) {
                result += resultMatrix.get(j, 0);
            }
            yMax = Math.max(y[i], yMax);
            yMin = Math.min(y[i], yMin);
            rmsd += Math.pow(y[i] - result, 2);
        }
        rmsd = Math.sqrt(rmsd / (double) x.length);
        return rmsd / (yMax - yMin);
    }

}
